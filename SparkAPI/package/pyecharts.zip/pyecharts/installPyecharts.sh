#!/bin/sh
	pip install lml-0.0.2-py2.py3-none-any.whl
	pip install dukpy-0.2.2-cp37-cp37m-manylinux1_x86_64.whl
	pip install macropy3-1.1.0b2.tar.gz
	pip install javascripthon-0.10.tar.gz
	pip install pyecharts_javascripthon-0.0.6-py2.py3-none-any.whl
	pip install jupyter-echarts-pypkg-0.1.2.tar.gz
	unzip pyecharts-0.5.10.zip
	cd pyecharts-0.5.10
	python setup.py install
	cd ..
	pip install pyecharts-snapshot-0.1.10.zip
	
	# 如果没有安装成功,则以下命令会出现错误,否则没有输出
	python -c "from pyecharts import Funnel"
	