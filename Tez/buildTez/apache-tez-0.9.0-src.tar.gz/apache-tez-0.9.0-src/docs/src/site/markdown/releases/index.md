<!--
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
-->

<head><title>Apache TEZ&reg; Releases</title></head>

Releases
------------
-   [Apache TEZ&reg; 0.9.0](./apache-tez-0-9-0.html) (Jul 27, 2017)
-   [Apache TEZ&reg; 0.8.5](./apache-tez-0-8-5.html) (Mar 13, 2017)
-   [Apache TEZ&reg; 0.8.4](./apache-tez-0-8-4.html) (Jul 08, 2016)
-   [Apache TEZ&reg; 0.8.3](./apache-tez-0-8-3.html) (Apr 15, 2016)
-   [Apache TEZ&reg; 0.8.2](./apache-tez-0-8-2.html) (Jan 19, 2016)
-   [Apache TEZ&reg; 0.8.1-alpha](./apache-tez-0-8-1-alpha.html) (Oct 12, 2015)
-   [Apache TEZ&reg; 0.8.0-alpha](./apache-tez-0-8-0-alpha.html) (Sep 01, 2015)
-   [Apache TEZ&reg; 0.7.1](./apache-tez-0-7-1.html) (May 10, 2016)
-   [Apache TEZ&reg; 0.7.0](./apache-tez-0-7-0.html) (May 18, 2015)
-   [Apache TEZ&reg; 0.6.2](./apache-tez-0-6-2.html) (Aug 07, 2015)
-   [Apache TEZ&reg; 0.6.1](./apache-tez-0-6-1.html) (May 18, 2015)
-   [Apache TEZ&reg; 0.6.0](./apache-tez-0-6-0.html) (Jan 23, 2015)
-   [Apache TEZ&reg; 0.5.4](./apache-tez-0-5-4.html) (Jun 26, 2015)
-   [Apache TEZ&reg; 0.5.3](./apache-tez-0-5-3.html) (Dec 10, 2014)
-   [Apache TEZ&reg; 0.5.2](./apache-tez-0-5-2.html) (Nov 07, 2014)
-   [Apache TEZ&reg; 0.5.1](./apache-tez-0-5-1.html) (Oct 08, 2014)
-   [Apache TEZ&reg; 0.5.0](./apache-tez-0-5-0.html) (Sep 04, 2014)
